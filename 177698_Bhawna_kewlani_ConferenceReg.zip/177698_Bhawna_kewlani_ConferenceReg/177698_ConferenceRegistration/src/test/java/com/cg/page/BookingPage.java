package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class BookingPage {
	WebDriver driver;

	@FindBy(how = How.ID, using = "txtFirstName")
	@CacheLookup
	private WebElement firstname;

	@FindBy(how = How.ID, using = "txtLastName")
	@CacheLookup
	private WebElement lastname;

	@FindBy(how = How.NAME, using = "Email")
	@CacheLookup
	private WebElement email;

	@FindBy(how = How.NAME, using = "Phone")
	@CacheLookup
	private WebElement mobileno;


	@FindBy(how = How.XPATH, using = "/html/body/form/table/tbody/tr[5]/td[2]/select")
	@CacheLookup
	private WebElement Noofpeople;
	
	
	@FindBy(how=How.NAME, using ="Address")
	@CacheLookup
	private WebElement Roomno;
	
	
	@FindBy(how=How.NAME, using ="Address2")
	@CacheLookup
	private WebElement area;
	

	@FindBy(how = How.XPATH, using = "/html/body/form/table/tbody/tr[9]/td[2]/select")
	@CacheLookup
	private WebElement city;

	@FindBy(how = How.XPATH, using = "/html/body/form/table/tbody/tr[10]/td[2]/select")
	@CacheLookup
	private WebElement state;
	
	@FindBy(how=How.NAME, using ="memberStatus")
	@CacheLookup
	private WebElement member;
	
	@FindBy(how = How.LINK_TEXT, using = "Next")
	@CacheLookup
	private WebElement nextlink;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public WebElement getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname); 
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno.sendKeys(mobileno);
	}

	public WebElement getNoofpeople() {
		return Noofpeople;
	}

	public void setNoofpeople(String noofpeople) {
		Noofpeople.sendKeys(noofpeople);
	}

	public WebElement getRoomno() {
		return Roomno;
	}

	public void setRoomno(String roomno) {
		Roomno.sendKeys(roomno);
	}

	public WebElement getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area.sendKeys(area);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getMember() {
		return member;
	}

	public void setMember(String member) {
		this.member.sendKeys(member);
	}

	public WebElement getNextlink() {
		return nextlink;
	}

	public void setNextlink(WebElement nextlink) {
		this.nextlink = nextlink;
	}
	public void NextLink() {
		this.nextlink.click();
	}

	public BookingPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public BookingPage() {
		super();
		// TODO Auto-generated constructor stub
	}
	


}
