package com.cg.paymentStep;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.page.BookingPage;
import com.cg.page.PaymentPage;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentDetails {
	
WebDriver driver;
	
	PaymentPage page;
	
	@Before
	public void setUp() {

		driver = BrowserFactory.startBrowser("chrome",
				"C:\\Users\\bkewlani\\Desktop\\Selenium_project\\177698_ConferenceRegistration\\src\\test\\java\\Html\\Payment.html");
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() {
		driver.close();
	}
	@Given("^Employee is on Payment Page$")
	public void employee_is_on_Payment_Page() throws Throwable {
		page = PageFactory.initElements(driver, PaymentPage.class);
		Thread.sleep(5000);
	}

	@Then("^Verify the title of Payment form$")
	public void verify_the_title_of_Payment_form() throws Throwable {
		assertEquals("Payment Details", driver.getTitle());
		if (driver.getTitle().equals("Payment Details")) {
			System.out.println("Title matched");
		} else {
			System.out.println("Title not matched");
		}
	}

	@When("^User leaves CardHolderName empty$")
	public void user_leaves_CardHolderName_empty() throws Throwable {
		page.setCardholdername("");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
		Thread.sleep(5000);
	}

	@Then("^Display CardHolderName Alert msg$")
	public void display_CardHolderName_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Card holder name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
		Thread.sleep(5000);
	}

	@When("^User leaves DebitCardNumber empty$")
	public void user_leaves_DebitCardNumber_empty() throws Throwable {
		page.setCardholdername("capgemini");
		page.setDebitcardno("");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		page.Confirmbooking();
		Thread.sleep(5000);
	}

	@Then("^Display DebitCardNumber Alert msg$")
	public void display_DebitCardNumber_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Debit card Number")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
		Thread.sleep(5000);
	}

	@When("^User leaves CardExpirationMonth empty$")
	public void user_leaves_CardExpirationMonth_empty() throws Throwable {
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("");
		page.setExpiryyear("2019");
		page.Confirmbooking();
		Thread.sleep(5000);
	}

	@Then("^Display CardExpirationMonth Alert msg$")
	public void display_CardExpirationMonth_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill expiration month")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
		Thread.sleep(5000);
	}

	@When("^User leaves CardExpirationYear empty$")
	public void user_leaves_CardExpirationYear_empty() throws Throwable {
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("");
		page.Confirmbooking();
		Thread.sleep(5000);
	}

	@Then("^Display CardExpirationYear Alert msg$")
	public void display_CardExpirationYear_Alert_msg() throws Throwable {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the expiration year")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
		Thread.sleep(5000);
	}

	@When("^User enters all details corectly$")
	public void user_enters_all_details_corectly() throws Throwable {
		page.setCardholdername("capgemini");
		page.setDebitcardno("74102589630147852");
		page.setCVV("741");
		page.setExpirymonth("08");
		page.setExpiryyear("2019");
		
		page.Confirmbooking();
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@Then("^Enter successful booking done$")
	public void enter_successful_booking_done() throws Throwable {
		Thread.sleep(1000);
		driver.navigate().to("C:\\Users\\bkewlani\\Desktop\\Selenium_project\\177698_ConferenceRegistration\\src\\test\\java\\Html\\success.html");
	}

}
