package com.cg.stepDefinition;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.internal.WebElementToJsonConverter;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.page.BookingPage;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferenceStepDefinition {

	WebDriver webDriver;
	BookingPage personaldetailspage;
	
	@Before
	public void setup() {
		webDriver=BrowserFactory.startBrowser("chrome", "C:\\Users\\bkewlani\\Desktop\\Selenium_project\\177698_ConferenceRegistration\\src\\test\\java\\Html\\ConferenceRegistration.html");
	}
	@After
	public void tearDown() {
		webDriver.close();
	}
	@Given("^Employee is on Registration Page$")
	public void employee_is_on_Registration_Page() throws InterruptedException  {
		personaldetailspage=PageFactory.initElements(webDriver, BookingPage.class);
		Thread.sleep(5000);
	   
	}

	@Then("^Verify the title of Registration form$")
	public void verify_the_title_of_Registration_form() throws InterruptedException  {
		assertEquals("Conference Registartion", webDriver.getTitle()); 
		  if(webDriver.getTitle().equals("Conference Registartion")) {
			  System.out.println("Title is matched");
		  }
		  else {
			  System.out.println("Not Matched");
			  webDriver.quit();
		  }
		  Thread.sleep(5000);
	    
	}

	@When("^Employee leaves firstname empty$")
	public void employee_leaves_firstname_empty() throws InterruptedException {
		personaldetailspage.setFirstname("");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setEmail("bhawnakewlani@gmail.com");
		personaldetailspage.setMobileno("7999068547");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("Maharashtra");
		personaldetailspage.setMember("member");
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	    
	}

	@Then("^Enter firstname alert$")
	public void enter_firstname_alert()  {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the First Name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	    
	}

	@When("^Employee leaves lastname empty$")
	public void employee_leaves_lastname_empty() throws InterruptedException {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("");
		personaldetailspage.setEmail("bhawnakewlani@gmail.com");
		personaldetailspage.setMobileno("7999068547");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("Maharashtra");
		personaldetailspage.setMember("member");
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	   
	}

	@Then("^Enter lastname alert$")
	public void enter_lastname_alert()  {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Last Name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	    
	}

	@When("^Employee leaves email empty$")
	public void employee_leaves_email_empty() throws InterruptedException {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setEmail("");
		personaldetailspage.setMobileno("7999068547");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("Maharashtra");
		personaldetailspage.setMember("member");
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	    
	}

	@Then("^Enter email alert$")
	public void enter_email_alert()  {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Email")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	    
	}

	@When("^Employee entered wrong email$")
	public void employee_entered_wrong_email(DataTable arg1) throws Throwable {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setMobileno("7999068547");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("Maharashtra");
		personaldetailspage.setMember("member");
		List<String> objlist = arg1.asList(String.class);
		for (int i = 0; i < objlist.size(); i++) {
			personaldetailspage.setEmail(objlist.get(i));
			Thread.sleep(1000);
			if (Pattern.matches("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$", objlist.get(i))) {
				System.out.println("**VAlid email -Matched " + objlist.get(i));
			} else {
				System.out.println("Invalid pattern");
			}
		}
		Thread.sleep(5000);
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	}

	@When("^Employee leaves mobileno empty$")
	public void employee_leaves_mobileno_empty() throws Throwable {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setEmail("bhawnakewlani@gmail.com");
		personaldetailspage.setMobileno("");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("Maharashtra");
		personaldetailspage.setMember("member");
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	}

	@Then("^Enter mobileno alert$")
	public void enter_mobileno_alert() throws Throwable {
		try {
			Alert alt = webDriver.switchTo().alert();
			webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
			String msg = alt.getText();
			if (msg.equals("Please fill the Contact No.")) {
				System.out.println("The text msg on alert box is: " + msg);
			} else {
				System.out.println("The text msg on alert box is not correct");
			}
			alt.accept();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@When("^Employee enter wrong number$")
	public void employee_enter_wrong_number(DataTable arg1) throws Throwable {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setEmail("bhawnakewlani@gmail.com");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("Maharashtra");
		personaldetailspage.setMember("member");
		List<String> objlist = arg1.asList(String.class);
		for (int i = 0; i < objlist.size(); i++) {
			personaldetailspage.setMobileno(objlist.get(i));
			Thread.sleep(1000);
			if (Pattern.matches("^[7-9]{1}[0-9]{9}$", objlist.get(i))) {
				System.out.println("**VAlid mobile no--Matched " + objlist.get(i));
			} else {
				System.out.println("Invalid pattern");
			}
		}
		Thread.sleep(5000);
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	}

	@When("^Employee leaves nop empty$")
	public void employee_leaves_nop_empty() throws Throwable {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setEmail("bhawnakewlani@gmail.com");
		personaldetailspage.setMobileno("7999068547");
		personaldetailspage.setNoofpeople("");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("Maharashtra");
		personaldetailspage.setMember("member");
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	}

	@Then("^Enter alert message$")
	public void enter_alert_message() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select no. of people")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^Employee leaves room no empty$")
	public void employee_leaves_room_no_empty() throws Throwable {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setEmail("bhawnakewlani@gmail.com");
		personaldetailspage.setMobileno("7999068547");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("Maharashtra");
		personaldetailspage.setMember("member");
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	}

	@Then("^Enter room empty message$")
	public void enter_room_empty_message() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please enter room no")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^Employee leaves city value empty$")
	public void employee_leaves_city_value_empty() throws Throwable {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setEmail("bhawnakewlani@gmail.com");
		personaldetailspage.setMobileno("7999068547");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("");
		personaldetailspage.setState("Maharashtra");
		personaldetailspage.setMember("member");
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	}

	@Then("^Enter City alert$")
	public void enter_City_alert() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select city")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^Employee leaves state empty$")
	public void employee_leaves_state_empty() throws Throwable {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setEmail("bhawnakewlani@gmail.com");
		personaldetailspage.setMobileno("7999068547");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("");
		personaldetailspage.setMember("member");
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	}

	@Then("^Enter State alert$")
	public void enter_State_alert() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select state")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();

	
	}

	@When("^Employee leaves conference status empty$")
	public void employee_leaves_conference_status_empty() throws Throwable {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setEmail("bhawnakewlani@gmail.com");
		personaldetailspage.setMobileno("7999068547");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("Maharashtra");
		personaldetailspage.setMember("");
		personaldetailspage.NextLink();
		Thread.sleep(5000);
	}

	@Then("^Enter conference status message$")
	public void enter_conference_status_message() throws Throwable {
		Alert alt = webDriver.switchTo().alert();
		webDriver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select status")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^Employee fill all the details$")
	public void employee_fill_all_the_details() throws Throwable {
		personaldetailspage.setFirstname("Bhawna");
		personaldetailspage.setLastname("Kewlani");
		personaldetailspage.setEmail("bhawnakewlani@gmail.com");
		personaldetailspage.setMobileno("7999068547");
		personaldetailspage.setNoofpeople("3");
		personaldetailspage.setRoomno("One");
		personaldetailspage.setArea("Capegmini");
		personaldetailspage.setCity("Pune");
		personaldetailspage.setState("Maharashtra");
		WebElement r1=webDriver.findElement(By.name("memberStatus"));
		r1.click();
		personaldetailspage.NextLink();
		webDriver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@Then("^Navigate to Payment page$")
	public void navigate_to_Payment_page() throws Throwable {
System.out.println("succesfful");
	    
	    webDriver.get("C:\\Users\\bkewlani\\Desktop\\Selenium_project\\177698_ConferenceRegistration\\src\\test\\java\\Html\\Payment.html");
	}

}
