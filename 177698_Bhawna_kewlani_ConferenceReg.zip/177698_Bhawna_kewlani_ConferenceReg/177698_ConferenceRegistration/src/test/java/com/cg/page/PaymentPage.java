package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PaymentPage {
	
	WebDriver driver;
	@FindBy(how = How.ID, using = "txtCardholderName")
	@CacheLookup
	private WebElement cardholdername;

	@FindBy(how = How.ID, using = "txtDebit")
	@CacheLookup
	private WebElement debitcardno;

	@FindBy(how = How.ID, using = "txtCvv")
	@CacheLookup
	private WebElement CVV;

	@FindBy(how = How.NAME, using = "month")
	@CacheLookup
	private WebElement expirymonth;

	@FindBy(how = How.NAME, using = "year")
	@CacheLookup
	private WebElement expiryyear;

	@FindBy(how = How.XPATH, using = "//*[@id=\"btnPayment\"]")
	@CacheLookup
	private WebElement confirmbooking;

	public WebElement getCardholdername() {
		return cardholdername;
	}

	public void setCardholdername(String cardholdername) {
		this.cardholdername.sendKeys(cardholdername);
	}

	public WebElement getDebitcardno() {
		return debitcardno;
	}

	public void setDebitcardno(String debitcardno) {
		this.debitcardno.sendKeys(debitcardno);
	}

	public WebElement getCVV() {
		return CVV;
	}

	public void setCVV(String cVV) {
		CVV.sendKeys(cVV);
	}

	public WebElement getExpirymonth() {
		return expirymonth;
	}

	public void setExpirymonth(String expirymonth) {
		this.expirymonth.sendKeys(expirymonth);
	}

	public WebElement getExpiryyear() {
		return expiryyear;
	}

	public void setExpiryyear(String expiryyear) {
		this.expiryyear.sendKeys(expiryyear);
	}

	public void Confirmbooking() {
		this.confirmbooking.click();
	}
	
	

}
