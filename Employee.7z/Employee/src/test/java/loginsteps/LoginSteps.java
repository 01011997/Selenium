package loginsteps;
import static org.junit.Assert.assertEquals;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.factory.BrowseFactory;

import com.cg.page.StudentLogin;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	
	WebDriver driver;
	StudentLogin page;
	
	@Before
	public void setUp() {

		driver = BrowseFactory.startBrowser("chrome",
				"file:///C:/Users/nehadesh/Desktop/Selenium/Employee/src/test/java/html/login.html");
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() {
		driver.close();
	}

@Given("^User is on Welcome to Student page$")
public void user_is_on_Welcome_to_Student_page() throws Exception {
    		page = PageFactory.initElements(driver, StudentLogin.class);

}

@Then("^Verify the title of the page$")
public void verify_the_title_of_the_page() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	assertEquals("Student Registration Form", page.getHeading());
	if (page.getHeading().equals("Student Registration Form")) {
		System.out.println("Heading matched");
	} else {
		System.out.println("Heading not matched");
	}
}

@Given("^User is on welcome Page$")
public void user_is_on_welcome_Page() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	page = PageFactory.initElements(driver, StudentLogin.class);
}

@When("^User leaves username empty$")
public void user_leaves_username_empty() throws Exception {
	page.setUsername("");
	page.setPassword("capg1234");
	page.setLogin();}

@When("^Clicks the login button$")
public void clicks_the_login_button() throws Exception {
	
}

@Then("^Display username Alert msg$")
public void display_username_Alert_msg() throws Exception {
driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
	
	
	if (page.getUserErrMsg().equals("* Please enter userName.")) {
		System.out.println("The text msg on alert box is: " + page.getUserErrMsg());
	} else {
		System.out.println("The text msg on alert box is not correct");
	}
}

@When("^User leaves password empty$")
public void user_leaves_password_empty() throws Exception {
	page.setUsername("Capgemini");
	page.setPassword("");
	page.setLogin();
}

@Then("^Display password Alert msg$")
public void display_password_Alert_msg() throws Exception {
	if (page.getPwdErrMsg().equals("* Please enter password.")) {
		System.out.println("The text msg on alert box is: " + page.getPwdErrMsg());
	} else {
		System.out.println("The text msg on alert box is not correct");
	}
	
}

@When("^User enters UserName and Password$")
public void user_enters_UserName_and_Password() throws Exception {
	page.setUsername("capgemini");
	page.setPassword("capg1234");
	page.setLogin();
}

@Then("^Message displayed Login Successfully$")
public void message_displayed_Login_Successfully() throws Exception {
	System.out.println("Login successful");
}



}
