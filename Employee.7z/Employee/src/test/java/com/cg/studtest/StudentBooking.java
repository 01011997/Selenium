package com.cg.studtest;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowseFactory;

import com.cg.page.StudentAdmission;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StudentBooking {
	
	WebDriver driver;
	StudentAdmission studeadd;
	@Before
	public void setUp() {

		driver = BrowseFactory.startBrowser("chrome",
				"file:///C:/Users/nehadesh/Desktop/Selenium/Employee/src/test/java/html/form.html");
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() {
		driver.close();
	}
	@Given("^User is on Welcome to StudentAdmission page$")
	public void user_is_on_Welcome_to_StudentAdmission_page() throws Exception {
		studeadd = PageFactory.initElements(driver, StudentAdmission.class);
	}

	@Then("^Verify the title of the page$")
	public void verify_the_title_of_the_page() throws Exception {
		assertEquals("StudentForm", driver.getTitle());
		if (driver.getTitle().equals("StudentForm")) {
			System.out.println("Title matched");
		} else {
			System.out.println("Title not matched");
		}
	}

	@When("^User leaves Firstname empty$")
	public void user_leaves_Firstname_empty() throws Exception {
		studeadd.setFirstname("");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("cap@gmail.com");
		studeadd.setMobileno("7998935662");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Tamilnadu");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("capgemini");
		studeadd.setDebitcardno("74102589630147852");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
	}

	@Then("^Display Firstname Alert msg$")
	public void display_Firstname_Alert_msg() throws Exception {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the First Name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
		
	}

	@When("^User leaves Lastname empty$")
	public void user_leaves_Lastname_empty() throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("");
		studeadd.setEmail("cap@gmail.com");
		studeadd.setMobileno("7998935662");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Tamilnadu");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("capgemini");
		studeadd.setDebitcardno("74102589630147852");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
	}

	@Then("^Display Lastname Alert msg$")
	public void display_Lastname_Alert_msg() throws Exception {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Last Name")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	}

	@When("^User leaves Email empty$")
	public void user_leaves_Email_empty() throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("");
		studeadd.setMobileno("7998935662");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Tamilnadu");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("capgemini");
		studeadd.setDebitcardno("74102589630147852");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
		Alert alt = driver.switchTo().alert();

		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Email")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	
	}

	/*@Then("^Display Email Alert msg$")
	public void display_Email_Alert_msg() throws Exception {
		
	}*/

	@When("^Student enters incorrect Email format and clicks the place order button$")
	public void student_enters_incorrect_Email_format_and_clicks_the_place_order_button(DataTable arg1) throws Exception {
		
		
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setMobileno("7998935662");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Tamilnadu");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("capgemini");
		studeadd.setDebitcardno("74102589630147852");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
		
		List<String> objlist = arg1.asList(String.class);
		for (int i = 0; i < objlist.size(); i++) {
			studeadd.setEmail(objlist.get(i));
			Thread.sleep(1000);
			if (Pattern.matches("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$", objlist.get(i))) {
				System.out.println("**VAlid email -Matched " + objlist.get(i));
			} else {
				System.out.println("Invalid pattern");
			}
		}
		studeadd.Confirmbooking();
	}
	
	@Then("^Enter valid email format$")
	public void Enter_valid_email_format() throws Exception {

		Alert alt = driver.switchTo().alert();

		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please Enter valid mail Address")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	
	}
	@When("^User leaves Mobileno empty$")
	public void user_leaves_Mobileno_empty() throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("neha.a.deshpande@capgemini.com");
		studeadd.setMobileno("");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Tamilnadu");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("capgemini");
		studeadd.setDebitcardno("74102589630147852");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
		
		
		Alert alt = driver.switchTo().alert();

		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the Mobile No.")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	}

	/*@Then("^Display Mobileno Alert msg$")
	public void display_Mobileno_Alert_msg() throws Exception {
		
		
	}*/

	@When("^Customer enters incorrect mobileNo format and clicks the place order button$")
	public void customer_enters_incorrect_mobileNo_format_and_clicks_the_place_order_button(DataTable arg1) throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("neha.a.deshpande@capgemini.com");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Tamilnadu");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("capgemini");
		studeadd.setDebitcardno("74102589630147852");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
		List<String> objlist = arg1.asList(String.class);
		for (int i = 0; i < objlist.size(); i++) {
			studeadd.setMobileno(objlist.get(i));
			Thread.sleep(1000);
			if (Pattern.matches("^[7-9]{1}[0-9]{9}", objlist.get(i))) {
				System.out.println("**VAlid mobile no--Matched " + objlist.get(i));
			} else {
				System.out.println("Invalid pattern");
			}
		}
		studeadd.Confirmbooking();
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please Enter a valid Mobile No.")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	}

	/*@Then("^Display Mobile Alert Mesage$")
	public void display_Mobile_Alert_Mesage() throws Exception {
		
		
	}*/

	@When("^User leaves City empty$")
	public void user_leaves_City_empty() throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("neha.a.deshpande@capgemini.com");
		studeadd.setMobileno("9766434593");
		studeadd.setAddress("MIPL");
		studeadd.setCity("");
		studeadd.setState("Tamilnadu");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("capgemini");
		studeadd.setDebitcardno("74102589630147852");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
	}

	@Then("^Display City Alert msg$")
	public void display_City_Alert_msg() throws Exception {
		Alert alt = driver.switchTo().alert();

		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select city")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	}

	@When("^User leaves State empty$")
	public void user_leaves_State_empty() throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("neha.a.deshpande@capgemini.com");
		studeadd.setMobileno("9766434593");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("capgemini");
		studeadd.setDebitcardno("74102589630147852");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
	}

	@Then("^Display State Alert msg$")
	public void display_State_Alert_msg() throws Exception {
		Alert alt = driver.switchTo().alert();

		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select state")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	}

	@When("^User leaves CardHolderName empty$")
	public void user_leaves_CardHolderName_empty() throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("neha.a.deshpande@capgemini.com");
		studeadd.setMobileno("9766434593");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Maharashtra");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("");
		studeadd.setDebitcardno("74102589630147852");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
	}

	@Then("^Display CardHolderName Alert msg$")
	public void display_CardHolderName_Alert_msg() throws Exception {
		Alert alt = driver.switchTo().alert();

		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please select CardholderName")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	}

	@When("^User leaves DebitCardNumber empty$")
	public void user_leaves_DebitCardNumber_empty() throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("neha.a.deshpande@capgemini.com");
		studeadd.setMobileno("9766434593");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Maharashtra");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("NehaDeshpande");
		studeadd.setDebitcardno("");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
	}

	@Then("^Display DebitCardNumber Alert msg$")
	public void display_DebitCardNumber_Alert_msg() throws Exception {
		Alert alt = driver.switchTo().alert();

		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please Enter DebitcardNo:")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	}

	@When("^User leaves CardExpirationMonth empty$")
	public void user_leaves_CardExpirationMonth_empty() throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("neha.a.deshpande@capgemini.com");
		studeadd.setMobileno("9766434593");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Maharashtra");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("NehaDeshpande");
		studeadd.setDebitcardno("123456789");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
	}

	@Then("^Display CardExpirationMonth Alert msg$")
	public void display_CardExpirationMonth_Alert_msg() throws Exception {
		Alert alt = driver.switchTo().alert();

		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill expiration month")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	}

	@When("^User leaves CardExpirationYear empty$")
	public void user_leaves_CardExpirationYear_empty() throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("neha.a.deshpande@capgemini.com");
		studeadd.setMobileno("9766434593");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Maharashtra");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("NehaDeshpande");
		studeadd.setDebitcardno("123456789");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("");
		studeadd.Confirmbooking();
	}

	@Then("^Display CardExpirationYear Alert msg$")
	public void display_CardExpirationYear_Alert_msg() throws Exception {
		Alert alt = driver.switchTo().alert();
//		to switch from register page to alert box
//		Thread.sleep(1000);
		// assertEquals("Please Enter The Customer Name", driver.getTitle());
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill the expiration year")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		Thread.sleep(5000);
		alt.accept();
	}

	@When("^User enters All Details correct$")
	public void user_enters_All_Details_correct() throws Exception {
		studeadd.setFirstname("Neha");
		studeadd.setLastname("Deshpande");
		studeadd.setEmail("neha.a.deshpande@capgemini.com");
		studeadd.setMobileno("9766434593");
		studeadd.setAddress("MIPL");
		studeadd.setCity("Chennai");
		studeadd.setState("Maharashtra");
		studeadd.setNoofpeople("3");
		studeadd.setCardholdername("NehaDeshpande");
		studeadd.setDebitcardno("123456789");
		studeadd.setCVV("741");
		studeadd.setExpirymonth("08");
		studeadd.setExpiryyear("2019");
		studeadd.Confirmbooking();
	}

	@Then("^Navigate to success page$")
	public void navigate_to_success_page() throws Exception {
		Thread.sleep(1000);
		driver.navigate().to("file:///C:/Users/nehadesh/Desktop/Selenium/Employee/src/test/java/html/Sucess.html");
	}


}
