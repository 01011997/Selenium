package com.cg.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import  cucumber.api.junit.*;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"},
features = {"C:\\Users\\nehadesh\\Desktop\\Selenium\\Employee\\loginfeatures"},
glue = {"loginsteps"})
public class StudentLoginTest {

}
