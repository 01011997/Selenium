package com.cg.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"},
features = {"C:\\Users\\nehadesh\\Desktop\\Selenium\\Employee\\formfeatures"},
glue = {"com.cg.studtest"})
public class StudentForm {
	
	
	

}
