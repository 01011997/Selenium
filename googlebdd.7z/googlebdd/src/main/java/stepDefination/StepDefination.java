package stepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
private WebDriver driver=new ChromeDriver();
WebElement searchBox;
@Given("^User is on Google Page$")
public void user_is_on_Google_Page() throws Exception {
	  System.setProperty("webdriver.chrome.driver", "C://Users//nehadesh//Desktop//selenium_jar//chromedriver_win32//chromedriver.exe"); // Write code here that turns the phrase above into concrete actions
	   driver=new ChromeDriver();
	   driver.get("http://www.google.com/");
	   Thread.sleep(5000);
    // Write code here that turns the phrase above into concrete actions
   
}

@When("^User enters a serch keyword$")
public void user_enters_a_serch_keyword() throws Exception {
	    searchBox = driver.findElement(By.xpath("//input[@name='q]"));
	 
    // Write code here that turns the phrase above into concrete actions
   
}

@Then("^it opens top search links$")
public void it_opens_top_search_links() throws Exception {
	searchBox.sendKeys("Cricket worldcup 2019");
	   searchBox.submit();
	   Thread.sleep(1000);
	   driver.quit();
    // Write code here that turns the phrase above into concrete actions
   
}


/*@Given("^User is on Google Page$")
public void user_is_on_Google_Page() throws Exception {
   System.setProperty("webdriver.chrome.driver", "C://Users//nehadesh//Desktop//selenium_jar//chromedriver_win32//chromedriver.exe"); // Write code here that turns the phrase above into concrete actions
   driver=new ChromeDriver();
   driver.get("http://www.google.com/");
   Thread.sleep(5000);
   //throw new PendingException();
}

@When("^User enters a serch keyword$")
public void user_enters_a_serch_keyword() {
    searchBox = driver.findElement(By.xpath("//input[@name='q]"));
}

@Then("^it opens top search links$")
public void it_opens_top_search_links() throws Exception {
   searchBox.sendKeys("Cricket worldcup 2019");
   searchBox.submit();
   Thread.sleep(1000);
   driver.quit();
    throw new PendingException();
}
*/







}
